package com.calc.alcohol.appalyzer;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


import static com.calc.alcohol.appalyzer.Kilaza.kg;
import static com.calc.alcohol.appalyzer.Spol.r;
import static com.calc.alcohol.appalyzer.Vrijeme.sati;

public class Alkohol extends Rez {
        CharSequence kolicinaVina;
        CharSequence kolicinaPiva;
        CharSequence kolicinaZeste;
        EditText t1;
        EditText t2;
        double db1;
        double db2;
        double db3;
        EditText t3;
        Button b1;
        double sum;
        public static double racunanje;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alkohol);




        t1 = (EditText) findViewById(R.id.kolkopiva);
        t2 = (EditText) findViewById(R.id.kolkovina);
        t3 = (EditText) findViewById(R.id.kolkozeste);
        b1 = (Button) findViewById(R.id.kraj);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                kolicinaPiva = t1.getText();
                kolicinaVina = t2.getText();
                kolicinaZeste = t3.getText();
                db1 =Double.parseDouble(kolicinaPiva.toString());
                db2 =Double.parseDouble(kolicinaVina.toString());
                db3 =Double.parseDouble(kolicinaZeste.toString());
                sum = db1*19.725 + db2*18.147 + db3*10.4148;
                racunanje= ((sum/( kg *1000* r))*100 - (sati*0.015))*10;



                Intent intent5;
                intent5 = new Intent(Alkohol.this, Rez.class);
                startActivity(intent5);
            }
        });

    }
}
