package com.calc.alcohol.appalyzer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import static com.calc.alcohol.appalyzer.Alkohol.racunanje;
public class Rez extends AppCompatActivity {
    TextView t1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rez);

        t1 = findViewById(R.id.textView2);
        t1.setText(Double.toString(racunanje));

    }
}
